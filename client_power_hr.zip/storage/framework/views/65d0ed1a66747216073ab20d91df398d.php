<img src="<?php echo e(URL::asset('images/logo.png')); ?>" alt="" class="hidden h-20 dark:block">
<img src="<?php echo e(URL::asset('images/logo.png')); ?>" alt="" class="block h-20 dark:hidden">
<?php /**PATH D:\mastagate\POWER-HR\hr_client\resources\views/components/application-logo.blade.php ENDPATH**/ ?>