<!DOCTYPE html>
<html lang="en" class="light scroll-smooth group" data-layout="vertical" data-sidebar="light" data-sidebar-size="lg"
    data-mode="light" data-topbar="light" data-skin="default" data-navbar="sticky" data-content="fluid" dir="ltr">

<head>
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>

    <meta name="theme-color" content="#888">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="">
    <meta name="description"
        content="Tapez votre mot-clé, puis cliquez sur Rechercher pour trouver votre emploi idéal. Peu importe le secteur, nous avons des offres adaptées à vos compétences." />
    <meta name="keywords"
        content="emploi, travail, offres d'emploi, trouver un emploi, carrière, recrutement, job, recherche d'emploi, domaine de compétence" />
    <link rel="canonical" href="#">
    <meta property="og:type" content="website" />
    <meta property="og:title"
        content="Trouvez l'emploi qui correspond à votre vie - Plateforme de recherche d'emploi" />
    <meta property="og:description"
        content="Peu importe votre secteur, trouvez l'emploi qui correspond à vos compétences. Recherchez dès maintenant votre poste idéal." />
    <meta property="og:image" content="<?php echo e(asset('build/images/logo.png')); ?>" />
    <meta property="og:url" content="#" />
    <meta property="og:image:width" content="1024" />
    <meta property="og:image:height" content="1024" />
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="<?php echo e(asset('build/images/logo.png')); ?>">

    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon/favicon-96x96.png')); ?>" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/favicon/favicon.svg')); ?>" />
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('images/favicon/apple-touch-icon.png')); ?>" />
    <link rel="manifest" href="<?php echo e(asset('images/favicon/site.webmanifest')); ?>" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('images/favicon/favicon.ico')); ?>">
    <?php echo $__env->make('layouts.head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Livewire Styles -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<!-- Content -->
<?php echo $__env->yieldContent('content'); ?>


<!-- Vendor Script -->
<?php echo $__env->make('layouts.vendor-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Livewire cript -->
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


</body>

</html>
<?php /**PATH D:\mastagate\POWER-HR\hr_client\resources\views/layouts/master-without-nav.blade.php ENDPATH**/ ?>