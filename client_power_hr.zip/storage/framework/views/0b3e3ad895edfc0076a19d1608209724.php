<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200 dark:border-zink-600"></div>
    </div>
</div>
<?php /**PATH /Users/user/Documents/web_projects/hr_client/resources/views/components/section-border.blade.php ENDPATH**/ ?>