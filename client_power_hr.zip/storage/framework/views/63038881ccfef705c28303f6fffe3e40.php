<!-- Layout config Js -->
<script src="<?php echo e(URL::asset('build/js/layout.js')); ?>"></script>
<?php echo $__env->yieldPushContent('css'); ?>
<!-- Icons CSS -->
<link rel="stylesheet" href="<?php echo e(URL::asset('build/css/icons.min.css')); ?>">
<!-- Tailwind CSS -->
<link rel="stylesheet" href="<?php echo e(URL::asset('build/css/tailwind.min.css')); ?>">   
<script>var app_url = '<?php echo e(env('APP_URL')); ?>' </script>
<?php /**PATH D:\Laravel\resources\views/layouts/head-css.blade.php ENDPATH**/ ?>