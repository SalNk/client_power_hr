<script src='<?php echo e(URL::asset('build/libs/choices.js/public/assets/scripts/choices.min.js')); ?>'></script>
<script src="<?php echo e(URL::asset('build/libs/@popperjs/core/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('build/libs/tippy.js/tippy-bundle.umd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('build/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('build/libs/prismjs/prism.js')); ?>"></script>
<script src="<?php echo e(URL::asset('build/libs/lucide/umd/lucide.js')); ?>"></script>
<script src="<?php echo e(URL::asset('build/js/tailwick.bundle.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH D:\Laravel\resources\views/layouts/vendor-scripts.blade.php ENDPATH**/ ?>