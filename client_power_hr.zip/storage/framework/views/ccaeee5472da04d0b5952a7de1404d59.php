<img src="<?php echo e(URL::asset('build/images/logo-light.png')); ?>" alt="" class="hidden h-6 dark:block">
<img src="<?php echo e(URL::asset('build/images/logo-dark.png')); ?>" alt="" class="block h-6 dark:hidden">
<?php /**PATH /Users/user/Documents/web_projects/hr_client/resources/views/components/application-logo.blade.php ENDPATH**/ ?>