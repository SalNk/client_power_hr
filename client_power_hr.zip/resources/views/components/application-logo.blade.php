<img src="{{ URL::asset('images/logo.png') }}" alt="" class="hidden h-20 dark:block">
<img src="{{ URL::asset('images/logo.png') }}" alt="" class="block h-20 dark:hidden">
